package com.kiyoshi.k7

import android.content.ContentUris
import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.provider.MediaStore
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import org.json.JSONArray
import org.json.JSONObject

class Song(
    val id: Long, val title: String, val artist: String, val album: String, val albumId: Long,
    val year: Int, val track: Int, val dur: Long, val added: Long, val folder: String
) {
    val uri: Uri get() = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)
    fun item(): MediaItem = MediaItem.Builder().setMediaId(id.toString()).setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album)
                .setArtworkUri(Uri.parse("content://media/external/audio/albumart/$albumId")).build()
        ).build()
}

object Store {
    lateinit var sp: SharedPreferences
    fun gi(k: String, d: Int) = sp.getInt(k, d)
    fun pi(k: String, v: Int) = sp.edit().putInt(k, v).apply()
    fun gs(k: String, d: String) = sp.getString(k, d) ?: d
    fun ps(k: String, v: String) = sp.edit().putString(k, v).apply()
    fun hasFolders() = sp.contains("folders")
    fun folders(): Set<String> = sp.getStringSet("folders", emptySet()) ?: emptySet()
    fun setFolders(s: Set<String>) = sp.edit().putStringSet("folders", s).apply()
    fun hidden(): Set<Long> = (sp.getStringSet("hid", emptySet()) ?: emptySet()).mapNotNull { it.toLongOrNull() }.toSet()
    fun setHidden(s: Set<Long>) = sp.edit().putStringSet("hid", s.map { it.toString() }.toSet()).apply()
    fun edits() = JSONObject(gs("ed", "{}"))
    fun setEdit(id: Long, t: String, a: String, al: String) {
        val o = edits(); o.put(id.toString(), JSONArray(listOf(t, a, al))); ps("ed", o.toString())
    }
    fun playlists(): Map<String, List<Long>> {
        val o = JSONObject(gs("pl", "{}"))
        return o.keys().asSequence().associateWith { k -> val a = o.getJSONArray(k); List(a.length()) { a.getLong(it) } }
    }
    fun savePlaylists(m: Map<String, List<Long>>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, JSONArray(v)) }; ps("pl", o.toString())
    }
}

object Covers {
    private val cache = android.util.LruCache<Long, Bitmap>(60)
    fun get(ctx: Context, s: Song): Bitmap? {
        val k = if (s.albumId > 0) s.albumId else -s.id
        cache.get(k)?.let { return it }
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(ctx, s.uri)
            r.embeddedPicture?.let {
                BitmapFactory.decodeByteArray(it, 0, it.size, BitmapFactory.Options().apply { inSampleSize = 2 })
            }?.also { cache.put(k, it) }
        } catch (e: Exception) { null } finally { r.release() }
    }
}

object Fx {
    private var eq: Equalizer? = null
    private var bass: BassBoost? = null
    fun attach(session: Int) {
        if (session == 0) return
        release()
        try { eq = Equalizer(0, session); bass = BassBoost(0, session) } catch (e: Exception) { }
        apply()
    }
    fun release() { eq?.release(); bass?.release(); eq = null; bass = null }
    fun levels(): List<Int> = Store.gs("eq", "0,0,0,0,0").split(",").map { it.toIntOrNull() ?: 0 }
    fun apply() {
        eq?.let { e ->
            try {
                e.enabled = Store.gi("eqOn", 0) == 1
                val r = e.bandLevelRange
                levels().forEachIndexed { i, v ->
                    if (i < e.numberOfBands) e.setBandLevel(i.toShort(), (v * 100).coerceIn(r[0].toInt(), r[1].toInt()).toShort())
                }
            } catch (x: Exception) { }
        }
        bass?.let { b ->
            try { b.enabled = Store.gi("bassOn", 0) == 1; b.setStrength((Store.gi("bass", 8) * 1000 / 15).toShort()) } catch (x: Exception) { }
        }
    }
}
