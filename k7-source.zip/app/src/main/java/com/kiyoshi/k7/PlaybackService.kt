package com.kiyoshi.k7

import android.content.Intent
import android.os.Handler
import android.os.Looper
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private val h = Handler(Looper.getMainLooper())

    // Transição suave: some no fim de cada música e entra no começo da próxima.
    private val tick = object : Runnable {
        override fun run() {
            val p = session?.player
            if (p != null) {
                val f = Store.gi("fade", 0) * 1000L
                var v = 1f
                if (f > 0 && p.isPlaying && p.duration > 0) {
                    val pos = p.currentPosition
                    val rem = p.duration - pos
                    v = if (rem < f) rem.toFloat() / f else if (pos < f) pos.toFloat() / f else 1f
                    v = v.coerceIn(0f, 1f)
                    if (Store.gi("curve", 1) == 1) v = v * v * (3 - 2 * v)
                    v = maxOf(v, 0.02f)
                }
                p.volume = v
            }
            h.postDelayed(this, 120)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build(), true
            )
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { Fx.attach(audioSessionId) }
        })
        Fx.attach(player.audioSessionId)
        session = MediaSession.Builder(this, player).build()
        h.post(tick)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    // Se o app for removido dos recentes, continua tocando; só encerra se estiver parado.
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        Fx.release()
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
