package com.kiyoshi.k7

import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

class PlaybackService : MediaSessionService() {
    private var session: MediaSession? = null
    private var sec: ExoPlayer? = null // segundo player: toca o final da música que está saindo
    private val h = Handler(Looper.getMainLooper())
    private var xEl = 0L
    private var xDur = 0L
    private var last = 0L
    private var prepKey: String? = null
    private var skipKey: String? = null

    private fun curve(t: Float): Float {
        val x = t.coerceIn(0f, 1f)
        return if (Store.gi("curve", 1) == 1) x * x * (3 - 2 * x) else x
    }

    // Crossfade real: nos últimos N s a próxima música entra no player principal enquanto
    // o final da atual continua no segundo player, saindo aos poucos.
    private val tick = object : Runnable {
        override fun run() {
            val p = session?.player
            val s = sec
            val now = SystemClock.uptimeMillis()
            val dt = minOf(now - last, 200L)
            last = now
            if (p != null && s != null) {
                if (xDur > 0) {
                    if (p.isPlaying) { xEl += dt; if (!s.isPlaying) s.play() } else if (s.isPlaying) s.pause()
                    val t = xEl.toFloat() / xDur
                    if (t >= 1f) { p.volume = 1f; s.stop(); s.clearMediaItems(); xDur = 0 }
                    else { p.volume = curve(t); s.volume = curve(1f - t) }
                } else {
                    p.volume = 1f
                    val f = Store.gi("fade", 0) * 1000L
                    val item = p.currentMediaItem
                    if (f > 0 && item != null && p.isPlaying && p.duration > 0 && p.hasNextMediaItem()) {
                        val key = "${item.mediaId}#${p.currentMediaItemIndex}"
                        val fl = minOf(f, p.duration / 3)
                        val rem = p.duration - p.currentPosition
                        if (key != skipKey) {
                            if (rem <= fl + 3000 && rem > fl) {
                                if (prepKey != key) {
                                    s.setMediaItem(item, p.currentPosition)
                                    s.volume = 1f
                                    s.playWhenReady = false
                                    s.prepare()
                                    prepKey = key
                                }
                            } else if (rem <= fl) {
                                if (prepKey == key) {
                                    s.seekTo(p.currentPosition)
                                    s.volume = 1f
                                    s.play()
                                    p.volume = 0f
                                    xEl = 0; xDur = fl; prepKey = null
                                    p.seekToNextMediaItem()
                                } else skipKey = key
                            }
                        }
                    }
                }
            }
            h.postDelayed(this, 50)
        }
    }

    override fun onCreate() {
        super.onCreate()
        val attrs = AudioAttributes.Builder().setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).setUsage(C.USAGE_MEDIA).build()
        val player = ExoPlayer.Builder(this)
            .setAudioAttributes(attrs, true)
            .setHandleAudioBecomingNoisy(true)
            .setWakeMode(C.WAKE_MODE_LOCAL)
            .build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) { Fx.attach(audioSessionId) }
        })
        Fx.attach(player.audioSessionId)
        sec = ExoPlayer.Builder(this).setAudioAttributes(attrs, false).setWakeMode(C.WAKE_MODE_LOCAL).build()
        session = MediaSession.Builder(this, player).build()
        h.post(tick)
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    // Se o app for removido dos recentes, continua tocando; só encerra se estiver parado.
    override fun onTaskRemoved(rootIntent: Intent?) {
        val p = session?.player
        if (p == null || !p.playWhenReady || p.mediaItemCount == 0) stopSelf()
    }

    override fun onDestroy() {
        h.removeCallbacks(tick)
        Fx.release()
        sec?.release(); sec = null
        session?.run { player.release(); release() }
        session = null
        super.onDestroy()
    }
}
