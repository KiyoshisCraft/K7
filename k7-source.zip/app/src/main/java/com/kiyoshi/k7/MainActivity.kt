package com.kiyoshi.k7

import android.Manifest
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media as M
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import java.io.File
import kotlin.concurrent.thread
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import androidx.activity.result.IntentSenderRequest
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.min
import kotlin.math.sqrt
import kotlin.math.roundToInt
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.unit.IntOffset
import androidx.media3.common.MediaItem

class MainActivity : ComponentActivity() {
    private var all by mutableStateOf(listOf<Song>())
    private var folders by mutableStateOf<Set<String>?>(if (Store.hasFolders()) Store.folders() else null)
    private var sort by mutableStateOf(Store.gs("sort", "az"))
    private var pls by mutableStateOf(Store.playlists())
    private var accent by mutableStateOf(Store.gi("accent", 0xFFFF6A4D.toInt()))
    private var bgc by mutableStateOf(Store.gi("bgc", 0xFF14110F.toInt()))
    private var eqOn by mutableStateOf(Store.gi("eqOn", 0) == 1)
    private var eqLv by mutableStateOf(Fx.levels())
    private var bassOn by mutableStateOf(Store.gi("bassOn", 0) == 1)
    private var bass by mutableStateOf(Store.gi("bass", 8))
    private var fade by mutableStateOf(Store.gi("fade", 0))
    private var curve by mutableStateOf(Store.gi("curve", 1))
    private val lib by derivedStateOf {
        val f = folders ?: emptySet()
        val l = all.filter { it.folder in f && it.id !in hidden && (query.isBlank() || "${it.title} ${it.artist} ${it.album}".contains(query, true)) }
        when (sort) {
            "artist" -> l.sortedWith(compareBy<Song>({ it.artist.lowercase() }, { it.title.lowercase() }))
            "album" -> l.sortedWith(compareBy<Song>({ it.album.lowercase() }, { it.track }))
            "new" -> l.sortedByDescending { it.added }
            "old" -> l.sortedBy { it.added }
            else -> l.sortedBy { it.title.lowercase() }
        }
    }

    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var title by mutableStateOf("K7")
    private var artist by mutableStateOf("Escolha uma música")
    private var playing by mutableStateOf(false)
    private var position by mutableStateOf(0L)
    private var duration by mutableStateOf(0L)
    private var curId by mutableStateOf<String?>(null)
    private var showPlayer by mutableStateOf(false)
    private var pTab by mutableStateOf(0)
    private var tab by mutableStateOf(0)
    private var openPl by mutableStateOf<String?>(null)
    private var dArtist by mutableStateOf<String?>(null)
    private var dAlbum by mutableStateOf<String?>(null)
    private var addTo by mutableStateOf<Song?>(null)
    private var showNew by mutableStateOf(false)
    private var newFor by mutableStateOf<Song?>(null)
    private var upd by mutableStateOf<Updater.Info?>(null)
    private var updMsg by mutableStateOf("")
    private var query by mutableStateOf("")
    private var queue by mutableStateOf(listOf<MediaItem>())
    private var qIdx by mutableStateOf(0)
    private var qEdit by mutableStateOf(false)
    private var sel by mutableStateOf<Set<Long>?>(null)
    private var hidden by mutableStateOf(Store.hidden())
    private var editSong by mutableStateOf<Song?>(null)
    private var barc by mutableStateOf(Store.gi("barc", 0xFF1E1A17.toInt()))
    private var thT by mutableStateOf(0)
    private var thV by mutableStateOf(1f)
    private var ctlTop by mutableStateOf(Store.gi("ctlTop", 0) == 1)
    private var barTop by mutableStateOf(Store.gi("barTop", 0) == 1)
    private val delLauncher = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) {
        if (it.resultCode == RESULT_OK) { sel = null; loadSongs() }
    }

    private val perms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loadSongs() }
    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { sync(player) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Color(accent), background = Color(bgc), surface = Color(bgc))) {
                Surface(Modifier.fillMaxSize(), color = Color(bgc)) { Screen() }
            }
        }
        checkUpdate(true)
        perms.launch(
            if (Build.VERSION.SDK_INT >= 33) arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        )
    }

    override fun onStart() {
        super.onStart()
        val f = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        future = f
        f.addListener({
            try { val c = f.get(); controller = c; c.addListener(listener); sync(c) } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        future?.let { MediaController.releaseFuture(it) }
        future = null; controller = null
        super.onStop()
    }

    private fun sync(p: Player) {
        playing = p.isPlaying
        if (p.mediaItemCount > 0) {
            title = p.mediaMetadata.title?.toString() ?: ""
            artist = p.mediaMetadata.artist?.toString() ?: ""
            curId = p.currentMediaItem?.mediaId
        }
        queue = List(p.mediaItemCount) { p.getMediaItemAt(it) }
        qIdx = p.currentMediaItemIndex
    }

    private fun play(list: List<Song>, i: Int) {
        controller?.apply { setMediaItems(list.map { it.item() }, i, 0L); prepare(); play() }
    }

    private fun loadSongs() = thread {
        val list = ArrayList<Song>()
        contentResolver.query(
            M.EXTERNAL_CONTENT_URI,
            arrayOf(M._ID, M.TITLE, M.ARTIST, M.ALBUM, M.ALBUM_ID, M.YEAR, M.TRACK, M.DURATION, M.DATE_ADDED, M.DATA),
            "${M.IS_MUSIC} != 0", null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val art = c.getString(2) ?: ""
                list.add(
                    Song(
                        c.getLong(0), c.getString(1) ?: "", if (art == "<unknown>" || art.isBlank()) "Desconhecido" else art,
                        c.getString(3) ?: "", c.getLong(4), c.getInt(5), c.getInt(6), c.getLong(7), c.getLong(8),
                        File(c.getString(9) ?: "").parent ?: ""
                    )
                )
            }
        }
        val ed = Store.edits()
        runOnUiThread {
            all = list.map { s ->
                val e = ed.optJSONArray(s.id.toString())
                if (e == null) s else Song(s.id, e.getString(0), e.getString(1), e.getString(2), s.albumId, s.year, s.track, s.dur, s.added, s.folder)
            }
        }
    }

    private fun saveEdit(s: Song, t: String, a: String, al: String) {
        Store.setEdit(s.id, t, a, al)
        all = all.map { if (it.id == s.id) Song(it.id, t, a, al, it.albumId, it.year, it.track, it.dur, it.added, it.folder) else it }
    }
    private fun hideSel() { val h = hidden + (sel ?: emptySet()); hidden = h; Store.setHidden(h); sel = null }
    private fun deleteSel() {
        val ids = sel ?: return
        if (Build.VERSION.SDK_INT >= 30) {
            val uris = all.filter { it.id in ids }.map { it.uri }
            delLauncher.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(contentResolver, uris).intentSender).build())
        } else Toast.makeText(this, "Apagar do aparelho exige Android 11 ou mais. Use Ocultar.", Toast.LENGTH_LONG).show()
    }

    private fun queueNext(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(listOf(s), 0) else c.addMediaItem(c.currentMediaItemIndex + 1, s.item())
    }
    private fun queueEnd(s: Song) {
        val c = controller ?: return
        if (c.mediaItemCount == 0) play(listOf(s), 0) else c.addMediaItem(s.item())
    }

    private fun commitPls(m: Map<String, List<Long>>) { pls = m; Store.savePlaylists(m) }
    private fun addToPl(name: String, s: Song?) {
        val m = pls.toMutableMap()
        m[name] = (m[name] ?: emptyList()) + (if (s != null && m[name]?.contains(s.id) != true) listOf(s.id) else emptyList())
        commitPls(m)
    }

    private fun checkUpdate(silent: Boolean) = thread {
        @Suppress("DEPRECATION") val cur = packageManager.getPackageInfo(packageName, 0).versionCode
        val info = try { Updater.check() } catch (e: Exception) { null }
        runOnUiThread {
            if (info != null && info.code > cur) { updMsg = "Versão atual: v$cur\nNova versão: v${info.code}"; upd = info }
            else if (!silent) Toast.makeText(this, if (info == null) "Não consegui verificar atualizações" else "Você já está na versão mais recente (v$cur)", Toast.LENGTH_LONG).show()
        }
    }

    private fun startUpdate(i: Updater.Info) {
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Permita instalar apps pelo K7 e toque em Atualizar de novo", Toast.LENGTH_LONG).show()
            return
        }
        updMsg = "Baixando…"
        thread {
            try { val f = Updater.download(this, i.url); runOnUiThread { upd = null; Updater.install(this, f) } }
            catch (e: Exception) { runOnUiThread { updMsg = "Falha no download. Tente de novo." } }
        }
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)
    private fun folderName(f: String) = f.trimEnd('/').split('/').takeLast(2).joinToString("/")

    // ---------------- UI ----------------
    @Composable
    private fun Screen() {
        LaunchedEffect(Unit) {
            while (true) {
                controller?.let { position = it.currentPosition; duration = maxOf(0L, it.duration) }
                kotlinx.coroutines.delay(250)
            }
        }
        BackHandler(showPlayer) { showPlayer = false }
        BackHandler(!showPlayer && (dAlbum != null || dArtist != null || openPl != null)) {
            if (dAlbum != null) dAlbum = null else if (dArtist != null) dArtist = null else openPl = null
        }
        upd?.let { u ->
            AlertDialog(
                onDismissRequest = { upd = null }, title = { Text("Atualização disponível") }, text = { Text(updMsg) },
                confirmButton = { TextButton(onClick = { startUpdate(u) }) { Text("Baixar e instalar") } },
                dismissButton = { TextButton(onClick = { upd = null }) { Text("Depois") } }
            )
        }
        addTo?.let { s ->
            AlertDialog(
                onDismissRequest = { addTo = null }, title = { Text("Adicionar à playlist") }, confirmButton = {},
                text = {
                    Column {
                        TextButton(onClick = { queueNext(s); addTo = null }) { Text("⏭ Tocar a seguir") }
                        TextButton(onClick = { queueEnd(s); addTo = null }) { Text("➕ Adicionar ao fim da fila") }
                        pls.keys.forEach { n -> TextButton(onClick = { addToPl(n, s); addTo = null }) { Text(n) } }
                        TextButton(onClick = { newFor = s; addTo = null; showNew = true }) { Text("＋ Nova playlist") }
                    }
                }
            )
        }
        if (showNew) {
            var nm by remember { mutableStateOf("") }
            AlertDialog(
                onDismissRequest = { showNew = false }, title = { Text("Nova playlist") },
                text = { OutlinedTextField(value = nm, onValueChange = { nm = it }, singleLine = true, label = { Text("Nome") }) },
                confirmButton = { TextButton(onClick = { if (nm.isNotBlank()) addToPl(nm.trim(), newFor); showNew = false; newFor = null }) { Text("Criar") } },
                dismissButton = { TextButton(onClick = { showNew = false }) { Text("Cancelar") } }
            )
        }
        editSong?.let { s ->
            var t by remember(s.id) { mutableStateOf(s.title) }
            var a by remember(s.id) { mutableStateOf(s.artist) }
            var al by remember(s.id) { mutableStateOf(s.album) }
            AlertDialog(
                onDismissRequest = { editSong = null }, title = { Text("Editar informações") },
                text = {
                    Column {
                        OutlinedTextField(t, { t = it }, label = { Text("Título") }, singleLine = true)
                        OutlinedTextField(a, { a = it }, label = { Text("Artista") }, singleLine = true)
                        OutlinedTextField(al, { al = it }, label = { Text("Álbum") }, singleLine = true)
                        Text("Vale dentro do K7; o arquivo original não é modificado.", style = MaterialTheme.typography.bodySmall)
                    }
                },
                confirmButton = { TextButton(onClick = { saveEdit(s, t.trim(), a.trim(), al.trim()); editSong = null }) { Text("Salvar") } },
                dismissButton = { TextButton(onClick = { editSong = null }) { Text("Cancelar") } }
            )
        }
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            if (showPlayer) PlayerView() else {
                Row(Modifier.fillMaxWidth().background(Color(barc)).padding(horizontal = 8.dp)) {
                    listOf("Músicas", "Playlists", "Discografia", "Ajustes").forEachIndexed { i, t ->
                        TextButton(onClick = { tab = i; sel = null }) {
                            Text(t, color = if (tab == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
                if (barTop) MiniBar()
                Box(Modifier.weight(1f)) {
                    when (tab) { 0 -> MusicTab(); 1 -> PlaylistTab(); 2 -> DiscTab(); else -> SettingsTab() }
                }
                if (!barTop) MiniBar()
            }
        }
    }

    @Composable
    private fun MiniBar() {
        Row(
            Modifier.fillMaxWidth().background(Color(barc)).clickable { showPlayer = true }
                .let { if (barTop) it else it.navigationBarsPadding() }.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            TextButton(onClick = { controller?.seekToPreviousMediaItem() }) { Text("⏮") }
            TextButton(onClick = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }) { Text(if (playing) "⏸" else "▶") }
            TextButton(onClick = { controller?.seekToNextMediaItem() }) { Text("⏭") }
        }
    }

    @Composable
    private fun ColorWheel(v: Float, onPick: (Int) -> Unit) {
        var sz by remember { mutableStateOf(1f) }
        fun pick(o: Offset) {
            val c = sz / 2
            val dx = o.x - c
            val dy = o.y - c
            val r = min(sqrt(dx * dx + dy * dy), c)
            val h = ((atan2(dy, dx) * 180 / PI + 360) % 360).toFloat()
            onPick(Color.hsv(h, r / c, v).toArgb())
        }
        Canvas(
            Modifier.padding(vertical = 8.dp).size(220.dp).onSizeChanged { sz = it.width.toFloat() }
                .pointerInput(v) { detectTapGestures { pick(it) } }
                .pointerInput(v) { detectDragGestures(onDragStart = { pick(it) }, onDrag = { c, _ -> pick(c.position) }) }
        ) {
            drawCircle(Brush.sweepGradient(List(7) { Color.hsv(it * 60f, 1f, v) }))
            drawCircle(Brush.radialGradient(listOf(Color.White, Color.Transparent)))
        }
    }

    @Composable
    private fun Cover(s: Song?, m: Modifier) {
        val ctx = LocalContext.current
        val bmp by produceState<Bitmap?>(null, s?.id) { value = if (s == null) null else withContext(Dispatchers.IO) { Covers.get(ctx, s) } }
        Box(m.clip(RoundedCornerShape(8.dp)).background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
            val b = bmp
            if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) else Text("♪")
        }
    }

    @Composable
    private fun SongRow(s: Song, list: List<Song>, i: Int) {
        Row(Modifier.fillMaxWidth().clickable { val q = sel; if (q != null) { sel = if (s.id in q) q - s.id else q + s.id } else { play(list, i); showPlayer = true } }.padding(horizontal = 16.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Cover(s, Modifier.size(44.dp))
            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                Text(s.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${s.artist} · ${s.album}", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            if (sel != null) Checkbox(checked = s.id in (sel ?: emptySet()), onCheckedChange = { c ->
                val q = sel ?: emptySet(); sel = if (c) q + s.id else q - s.id
            }) else {
                TextButton(onClick = { addTo = s }) { Text("＋") }
                TextButton(onClick = { editSong = s }) { Text("✎") }
            }
        }
    }

    @Composable
    private fun MusicTab() {
        if (folders.isNullOrEmpty()) {
            Column(Modifier.padding(24.dp)) {
                Text("Escolha quais pastas o K7 deve mostrar.")
                TextButton(onClick = { tab = 3 }) { Text("Escolher pastas") }
            }
            return
        }
        val names = listOf("az" to "A–Z", "artist" to "Artista", "album" to "Álbum", "new" to "Mais recentes", "old" to "Mais antigas")
        var menu by remember { mutableStateOf(false) }
        val l = lib
        val q = sel
        Column {
            OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth().padding(horizontal = 12.dp), singleLine = true, placeholder = { Text("Buscar música, artista ou álbum") })
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (q == null) {
                    Box {
                        TextButton(onClick = { menu = true }) { Text("Ordenar: ${names.first { it.first == sort }.second} ▾") }
                        DropdownMenu(menu, { menu = false }) {
                            names.forEach { (k, n) -> DropdownMenuItem(text = { Text(n) }, onClick = { sort = k; Store.ps("sort", k); menu = false }) }
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { sel = emptySet() }) { Text("Selecionar") }
                } else {
                    TextButton(onClick = { sel = l.map { it.id }.toSet() }) { Text("Todas") }
                    TextButton(onClick = { hideSel() }, enabled = q.isNotEmpty()) { Text("Ocultar (${q.size})") }
                    TextButton(onClick = { deleteSel() }, enabled = q.isNotEmpty()) { Text("Apagar") }
                    TextButton(onClick = { sel = null }) { Text("Cancelar") }
                }
            }
            LazyColumn { itemsIndexed(l) { i, s -> SongRow(s, l, i) } }
        }
    }

    @Composable
    private fun PlaylistTab() {
        val name = openPl
        if (name == null) {
            Column {
                TextButton(onClick = { newFor = null; showNew = true }) { Text("＋ Nova playlist") }
                LazyColumn {
                    items(pls.keys.toList()) { n ->
                        Text("$n  (${pls[n]?.size ?: 0})", Modifier.fillMaxWidth().clickable { openPl = n }.padding(16.dp))
                    }
                }
            }
        } else {
            val l = pls[name]?.mapNotNull { id -> all.firstOrNull { it.id == id } } ?: emptyList()
            Column {
                Text("‹ $name", Modifier.clickable { openPl = null }.padding(16.dp), style = MaterialTheme.typography.titleMedium)
                LazyColumn { itemsIndexed(l) { i, s -> SongRow(s, l, i) } }
            }
        }
    }

    @Composable
    private fun DiscTab() {
        val a = dArtist
        val al = dAlbum
        if (a == null) {
            val g = lib.groupBy { it.artist }
            LazyColumn {
                items(g.keys.sortedBy { it.lowercase() }) { k ->
                    val v = g[k]!!
                    Column(Modifier.fillMaxWidth().clickable { dArtist = k }.padding(16.dp)) {
                        Text(k)
                        Text("${v.map { it.album }.distinct().size} álbuns · ${v.size} faixas", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        } else if (al == null) {
            val g = lib.filter { it.artist == a }.groupBy { it.album }
            Column {
                Text("‹ $a", Modifier.clickable { dArtist = null }.padding(16.dp), style = MaterialTheme.typography.titleMedium)
                LazyColumn {
                    items(g.keys.sortedBy { k -> g[k]!!.maxOf { it.year } }) { k ->
                        val v = g[k]!!
                        Row(Modifier.fillMaxWidth().clickable { dAlbum = k }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Cover(v[0], Modifier.size(56.dp))
                            Column(Modifier.padding(start = 12.dp)) {
                                Text(k)
                                Text("${v.maxOf { it.year }.takeIf { it > 0 } ?: "—"} · ${v.size} faixas", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        } else {
            val l = lib.filter { it.artist == a && it.album == al }.sortedBy { it.track % 1000 }
            val y = l.maxOfOrNull { it.year } ?: 0
            Column {
                Text("‹ $a", Modifier.clickable { dAlbum = null }.padding(16.dp), style = MaterialTheme.typography.titleMedium)
                LazyColumn {
                    item {
                        Column(Modifier.fillMaxWidth().padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                            Cover(l.firstOrNull(), Modifier.size(240.dp))
                            Text(al, style = MaterialTheme.typography.titleLarge, modifier = Modifier.padding(top = 12.dp))
                            Text("$a · ${if (y > 0) y else "ano desconhecido"}")
                            Text("${l.size} faixas · ${l.sumOf { it.dur } / 60000} min", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    itemsIndexed(l) { i, s ->
                        Row(Modifier.fillMaxWidth().clickable { play(l, i); showPlayer = true }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                            Text("${(s.track % 1000).takeIf { it > 0 } ?: (i + 1)}".padStart(2, '0'), Modifier.width(36.dp))
                            Text(s.title, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(fmt(s.dur), style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            }
        }
    }

    @Composable
    private fun SettingsTab() {
        val groups = all.groupBy { it.folder }
        val tn = listOf("Destaque", "Fundo", "Barras")
        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            item {
                Text("Cores", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                Row {
                    tn.forEachIndexed { i, n ->
                        TextButton(onClick = { thT = i }) { Text(n, color = if (thT == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) }
                    }
                }
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    ColorWheel(thV) { c ->
                        when (thT) {
                            0 -> { accent = c; Store.pi("accent", c) }
                            1 -> { bgc = c; Store.pi("bgc", c) }
                            else -> { barc = c; Store.pi("barc", c) }
                        }
                    }
                }
                Text("Brilho", style = MaterialTheme.typography.bodySmall)
                Slider(thV, { thV = it }, valueRange = 0.2f..1f)
                TextButton(onClick = {
                    accent = 0xFFFF6A4D.toInt(); bgc = 0xFF14110F.toInt(); barc = 0xFF1E1A17.toInt()
                    Store.pi("accent", accent); Store.pi("bgc", bgc); Store.pi("barc", barc)
                }) { Text("Restaurar cores") }
                Text("Posição dos botões", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Controles do player no topo", Modifier.weight(1f))
                    Switch(ctlTop, { ctlTop = it; Store.pi("ctlTop", if (it) 1 else 0) })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Barra “tocando agora” no topo", Modifier.weight(1f))
                    Switch(barTop, { barTop = it; Store.pi("barTop", if (it) 1 else 0) })
                }
                Text("Pastas de música", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 12.dp))
                Row {
                    TextButton(onClick = { folders = groups.keys; Store.setFolders(groups.keys) }) { Text("Todas") }
                    TextButton(onClick = { folders = emptySet(); Store.setFolders(emptySet()) }) { Text("Nenhuma") }
                }
            }
            items(groups.keys.sorted()) { f ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = folders?.contains(f) == true, onCheckedChange = { c ->
                        val st = (folders ?: emptySet()).toMutableSet()
                        if (c) st.add(f) else st.remove(f)
                        folders = st; Store.setFolders(st)
                    })
                    Text("${folderName(f)} (${groups[f]!!.size})")
                }
            }
            item {
                if (hidden.isNotEmpty()) TextButton(onClick = { hidden = emptySet(); Store.setHidden(emptySet()) }) { Text("Mostrar músicas ocultas (${hidden.size})") }
                TextButton(onClick = { checkUpdate(false) }) { Text("⟳ Verificar atualização") }
            }
        }
    }

    @Composable
    private fun ColumnScope.PlayerView() {
        val cur = all.firstOrNull { it.id.toString() == curId }
        Column(Modifier.weight(1f).fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showPlayer = false }) { Text("⌄ Voltar") }
                Spacer(Modifier.weight(1f))
                listOf("Capa", "Fila", "DJ").forEachIndexed { i, t ->
                    TextButton(onClick = { pTab = i }) { Text(t, color = if (pTab == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) }
                }
            }
            Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, maxLines = 1)
            if (ctlTop) PlayerControls()
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                when (pTab) { 0 -> Cover(cur, Modifier.fillMaxWidth().aspectRatio(1f)); 1 -> QueueView(); else -> DjView() }
            }
            if (!ctlTop) PlayerControls()
        }
    }

    @Composable
    private fun PlayerControls() {
        Column(Modifier.fillMaxWidth()) {
            Slider(
                value = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                onValueChange = { controller?.seekTo((it * duration).toLong()) }
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmt(position), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                Text(fmt(duration), style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton(onClick = { controller?.seekToPreviousMediaItem() }) { Text("⏮", style = MaterialTheme.typography.headlineMedium) }
                TextButton(onClick = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }) { Text(if (playing) "⏸" else "▶", style = MaterialTheme.typography.headlineMedium) }
                TextButton(onClick = { controller?.seekToNextMediaItem() }) { Text("⏭", style = MaterialTheme.typography.headlineMedium) }
            }
        }
    }

    @Composable
    private fun DjView() {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Equalizador", Modifier.weight(1f))
                Switch(eqOn, { eqOn = it; Store.pi("eqOn", if (it) 1 else 0); Fx.apply() })
            }
            listOf("60 Hz", "230 Hz", "910 Hz", "3,6 kHz", "14 kHz").forEachIndexed { i, n ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(n, Modifier.width(64.dp), style = MaterialTheme.typography.bodySmall)
                    Slider(
                        value = (eqLv.getOrElse(i) { 0 }).toFloat(),
                        onValueChange = { v -> eqLv = eqLv.toMutableList().also { l -> l[i] = v.toInt() }; Store.ps("eq", eqLv.joinToString(",")); Fx.apply() },
                        valueRange = -12f..12f, steps = 23, modifier = Modifier.weight(1f)
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Amplificador de graves", Modifier.weight(1f))
                Switch(bassOn, { bassOn = it; Store.pi("bassOn", if (it) 1 else 0); Fx.apply() })
            }
            Slider(bass.toFloat(), { v -> bass = v.toInt(); Store.pi("bass", bass); Fx.apply() }, valueRange = 0f..15f, steps = 14)
            Text("Crossfade: ${if (fade == 0) "desligado" else "$fade s de mistura entre as músicas"}")
            Slider(fade.toFloat(), { v -> fade = v.toInt(); Store.pi("fade", fade) }, valueRange = 0f..12f, steps = 11)
            Row {
                TextButton(onClick = { curve = 0; Store.pi("curve", 0) }) { Text("Linear", color = if (curve == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) }
                TextButton(onClick = { curve = 1; Store.pi("curve", 1) }) { Text("Suave", color = if (curve == 1) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface) }
            }
        }
    }

    @Composable
    private fun QueueView() {
        val q = queue
        Column(Modifier.fillMaxSize()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Fila (${q.size})", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                TextButton(onClick = { qEdit = !qEdit }) { Text(if (qEdit) "Concluir" else "Editar ordem") }
            }
            Text(
                if (qEdit) "Use ▲ ▼ para mudar a ordem e ⏭ para tocar a seguir." else "Toque para tocar. Arraste para a esquerda para remover.",
                style = MaterialTheme.typography.bodySmall
            )
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(q, key = { i, m -> "${m.mediaId}#$i" }) { i, m ->
                    var dx by remember { mutableStateOf(0f) }
                    val cur = i == qIdx
                    val col = if (cur) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface
                    Row(
                        Modifier.fillMaxWidth().offset { IntOffset(dx.roundToInt(), 0) }
                            .pointerInput(i) {
                                detectHorizontalDragGestures(
                                    onDragEnd = { if (dx < -200f) controller?.removeMediaItem(i); dx = 0f },
                                    onDragCancel = { dx = 0f },
                                    onHorizontalDrag = { _, d -> dx = minOf(0f, dx + d) }
                                )
                            }
                            .clickable { controller?.seekTo(i, 0L) }.padding(vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(if (cur) "▶" else "${i + 1}", Modifier.width(32.dp), color = col)
                        Column(Modifier.weight(1f)) {
                            Text(m.mediaMetadata.title?.toString() ?: "", color = col, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(m.mediaMetadata.artist?.toString() ?: "", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (qEdit) {
                            TextButton(onClick = { if (i > 0) controller?.moveMediaItem(i, i - 1) }) { Text("▲") }
                            TextButton(onClick = { if (i < q.size - 1) controller?.moveMediaItem(i, i + 1) }) { Text("▼") }
                            TextButton(onClick = {
                                controller?.let { c ->
                                    val ci = c.currentMediaItemIndex
                                    if (i != ci) c.moveMediaItem(i, if (i > ci) ci + 1 else ci)
                                }
                            }) { Text("⏭") }
                        }
                    }
                }
            }
        }
    }
}
