package com.kiyoshi.k7

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private val songs = mutableStateListOf<MediaItem>()
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var title by mutableStateOf("K7")
    private var artist by mutableStateOf("Escolha uma música")
    private var playing by mutableStateOf(false)

    private val perms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { loadSongs() }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { sync(player) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
        perms.launch(
            if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        )
    }

    override fun onStart() {
        super.onStart()
        val f = MediaController.Builder(
            this, SessionToken(this, ComponentName(this, PlaybackService::class.java))
        ).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                sync(c)
            } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    private fun sync(p: Player) {
        playing = p.isPlaying
        if (p.mediaItemCount > 0) {
            title = p.mediaMetadata.title?.toString() ?: ""
            artist = p.mediaMetadata.artist?.toString() ?: ""
        }
    }

    private fun play(i: Int) {
        controller?.apply {
            setMediaItems(songs.toList(), i, 0L)
            prepare()
            play()
        }
    }

    private fun loadSongs() = thread {
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val list = ArrayList<MediaItem>()
        contentResolver.query(
            base,
            arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM_ID
            ),
            "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                list.add(
                    MediaItem.Builder()
                        .setMediaId(id.toString())
                        .setUri(ContentUris.withAppendedId(base, id))
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(c.getString(1))
                                .setArtist(c.getString(2))
                                .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${c.getLong(3)}"))
                                .build()
                        ).build()
                )
            }
        }
        runOnUiThread { songs.clear(); songs.addAll(list) }
    }

    @Composable
    private fun Screen() {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Text("K7", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.padding(16.dp))
            if (songs.isEmpty()) Text("Nenhuma música encontrada (ou sem permissão).", modifier = Modifier.padding(16.dp))
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(songs) { i, m ->
                    Column(Modifier.fillMaxWidth().clickable { play(i) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                        Text(m.mediaMetadata.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            m.mediaMetadata.artist?.toString() ?: "",
                            style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }
            Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = { controller?.seekToPreviousMediaItem() }) { Text("⏮") }
                TextButton(onClick = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }) { Text(if (playing) "⏸" else "▶") }
                TextButton(onClick = { controller?.seekToNextMediaItem() }) { Text("⏭") }
            }
        }
    }
}
