package com.kiyoshi.k7

import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Updater {
    // Repositório do GitHub onde as versões são publicadas (Releases).
    const val REPO = "KiyoshisCraft/K7"

    class Info(val code: Int, val name: String, val url: String)

    fun check(): Info? {
        val c = URL("https://api.github.com/repos/$REPO/releases/latest").openConnection() as HttpURLConnection
        c.setRequestProperty("Accept", "application/vnd.github+json")
        c.connectTimeout = 10000; c.readTimeout = 10000
        if (c.responseCode != 200) return null
        val j = JSONObject(c.inputStream.bufferedReader().readText())
        val tag = j.getString("tag_name")
        val code = tag.filter { it.isDigit() }.toIntOrNull() ?: return null
        val a = j.getJSONArray("assets")
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            if (o.getString("name").endsWith(".apk")) return Info(code, tag, o.getString("browser_download_url"))
        }
        return null
    }

    fun download(ctx: Context, url: String): File {
        val f = File(File(ctx.cacheDir, "updates").apply { mkdirs() }, "k7.apk")
        val c = URL(url).openConnection() as HttpURLConnection
        c.instanceFollowRedirects = true
        c.inputStream.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
        return f
    }

    fun install(ctx: Context, f: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
