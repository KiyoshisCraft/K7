package com.kiyoshi.k7

import android.app.Application

class K7App : Application() {
    override fun onCreate() { super.onCreate(); Store.sp = getSharedPreferences("k7", 0) }
}
