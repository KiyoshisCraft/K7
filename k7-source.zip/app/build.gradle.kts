plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
val vc = (project.findProperty("versionCode") as String?)?.toIntOrNull() ?: 1
android {
    namespace = "com.kiyoshi.k7"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.kiyoshi.k7"
        minSdk = 26
        targetSdk = 34
        versionCode = vc
        versionName = "1.$vc"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    signingConfigs {
        create("k7") {
            storeFile = file("k7.jks")
            storePassword = "k7k7k7"
            keyAlias = "k7"
            keyPassword = "k7k7k7"
        }
    }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("k7") } }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.media3:media3-exoplayer:1.3.1")
    implementation("androidx.media3:media3-session:1.3.1")
}
