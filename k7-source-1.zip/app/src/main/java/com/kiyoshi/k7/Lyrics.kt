package com.kiyoshi.k7

import android.content.Context
import android.net.Uri
import java.io.DataInputStream

/** Lê letras gravadas dentro do MP3 (ID3: SYLT sincronizada, ou USLT com ou sem marcas [mm:ss.xx]). */
object Lyrics {
    class Line(val ms: Long, val text: String)
    class Result(val lines: List<Line>, val synced: Boolean)
    private val ts = Regex("\\[(\\d+):(\\d+)(?:[.:](\\d+))?]")

    fun read(ctx: Context, uri: Uri): Result? = try {
        ctx.contentResolver.openInputStream(uri)?.use { s ->
            val d = DataInputStream(s.buffered())
            val h = ByteArray(10); d.readFully(h)
            if (h[0] != 'I'.code.toByte() || h[1] != 'D'.code.toByte() || h[2] != '3'.code.toByte()) return@use null
            val tag = ByteArray(minOf(synch(h, 6), 16_000_000)); d.readFully(tag)
            parseTag(tag, h[3].toInt())
        }
    } catch (e: Exception) { null }

    private fun synch(b: ByteArray, o: Int) =
        ((b[o].toInt() and 127) shl 21) or ((b[o + 1].toInt() and 127) shl 14) or ((b[o + 2].toInt() and 127) shl 7) or (b[o + 3].toInt() and 127)
    private fun be(b: ByteArray, o: Int) =
        ((b[o].toInt() and 255) shl 24) or ((b[o + 1].toInt() and 255) shl 16) or ((b[o + 2].toInt() and 255) shl 8) or (b[o + 3].toInt() and 255)
    private fun tl(enc: Int) = if (enc == 1 || enc == 2) 2 else 1
    private fun term(b: ByteArray, from: Int, enc: Int): Int {
        var i = from
        if (enc == 0 || enc == 3) { while (i < b.size && b[i].toInt() != 0) i++ }
        else { while (i + 1 < b.size && !(b[i].toInt() == 0 && b[i + 1].toInt() == 0)) i += 2 }
        return minOf(i, b.size)
    }
    private fun dec(b: ByteArray, s: Int, e: Int, enc: Int): String =
        if (e <= s) "" else String(b, s, e - s, when (enc) { 0 -> Charsets.ISO_8859_1; 1 -> Charsets.UTF_16; 2 -> Charsets.UTF_16BE; else -> Charsets.UTF_8 })

    private fun parseTag(t: ByteArray, v: Int): Result? {
        var o = 0
        var sylt: Result? = null
        var uslt: Result? = null
        while (o + 10 <= t.size && t[o].toInt() != 0) {
            val id = String(t, o, 4, Charsets.ISO_8859_1)
            val sz = if (v == 4) synch(t, o + 4) else be(t, o + 4)
            if (sz <= 0 || o + 10 + sz > t.size) break
            val data = t.copyOfRange(o + 10, o + 10 + sz)
            o += 10 + sz
            if (id == "SYLT" && sylt == null) sylt = parseSylt(data)
            else if (id == "USLT" && uslt == null) uslt = parseUslt(data)
        }
        return sylt ?: uslt
    }

    private fun parseUslt(d: ByteArray): Result? {
        if (d.size < 5) return null
        val enc = d[0].toInt()
        val s = term(d, 4, enc) + tl(enc)
        return if (s >= d.size) null else parseText(dec(d, s, d.size, enc))
    }

    private fun parseSylt(d: ByteArray): Result? {
        if (d.size < 7) return null
        val enc = d[0].toInt()
        val fmt = d[4].toInt()
        var i = term(d, 6, enc) + tl(enc)
        val out = ArrayList<Line>()
        while (i < d.size) {
            val e = term(d, i, enc)
            val text = dec(d, i, e, enc).trim()
            i = e + tl(enc)
            if (i + 4 > d.size) break
            val ms = be(d, i).toLong(); i += 4
            if (text.isNotEmpty()) out.add(Line(ms, text))
        }
        return if (fmt == 2 && out.isNotEmpty()) Result(out, true) else null
    }

    private fun parseText(text: String): Result {
        val out = ArrayList<Line>()
        var synced = false
        for (raw in text.lines()) {
            val m = ts.findAll(raw).toList()
            val t = raw.replace(ts, "").trim()
            if (m.isEmpty()) out.add(Line(-1, raw.trim()))
            else {
                synced = true
                for (x in m) {
                    val f = x.groupValues[3].padEnd(3, '0').take(3).toInt()
                    out.add(Line(x.groupValues[1].toLong() * 60000 + x.groupValues[2].toLong() * 1000 + f, t))
                }
            }
        }
        if (synced) { out.removeAll { it.ms < 0 }; out.sortBy { it.ms } }
        return Result(out, synced)
    }
}
