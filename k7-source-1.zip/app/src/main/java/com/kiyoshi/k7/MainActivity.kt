package com.kiyoshi.k7

import android.Manifest
import android.content.ComponentName
import android.content.ContentUris
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.google.common.util.concurrent.ListenableFuture
import kotlin.concurrent.thread

class MainActivity : ComponentActivity() {
    private val songs = mutableStateListOf<MediaItem>()
    private var future: ListenableFuture<MediaController>? = null
    private var controller: MediaController? = null
    private var title by mutableStateOf("K7")
    private var artist by mutableStateOf("Escolha uma música")
    private var playing by mutableStateOf(false)
    private var lyrics by mutableStateOf<Lyrics.Result?>(null)
    private var position by mutableStateOf(0L)
    private var duration by mutableStateOf(0L)
    private var showPlayer by mutableStateOf(false)
    private var showLyrics by mutableStateOf(true)
    private var curId: String? = null
    private var upd by mutableStateOf<Updater.Info?>(null)
    private var updMsg by mutableStateOf("")

    private val perms = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { loadSongs() }

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) { sync(player) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { Screen() }
            }
        }
        checkUpdate(true)
        perms.launch(
            if (Build.VERSION.SDK_INT >= 33)
                arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
            else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        )
    }

    override fun onStart() {
        super.onStart()
        val f = MediaController.Builder(
            this, SessionToken(this, ComponentName(this, PlaybackService::class.java))
        ).buildAsync()
        future = f
        f.addListener({
            try {
                val c = f.get()
                controller = c
                c.addListener(listener)
                sync(c)
            } catch (e: Exception) { }
        }, ContextCompat.getMainExecutor(this))
    }

    override fun onStop() {
        future?.let { MediaController.releaseFuture(it) }
        future = null
        controller = null
        super.onStop()
    }

    private fun sync(p: Player) {
        playing = p.isPlaying
        if (p.mediaItemCount > 0) {
            title = p.mediaMetadata.title?.toString() ?: ""
            artist = p.mediaMetadata.artist?.toString() ?: ""
            val id = p.currentMediaItem?.mediaId
            if (id != curId) {
                curId = id
                lyrics = null
                val uri = p.currentMediaItem?.localConfiguration?.uri
                if (uri != null) thread {
                    val r = Lyrics.read(this, uri)
                    runOnUiThread { if (curId == id) lyrics = r }
                }
            }
        }
    }

    private fun play(i: Int) {
        controller?.apply {
            setMediaItems(songs.toList(), i, 0L)
            prepare()
            play()
        }
    }

    private fun loadSongs() = thread {
        val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val list = ArrayList<MediaItem>()
        contentResolver.query(
            base,
            arrayOf(
                MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM_ID
            ),
            "${MediaStore.Audio.Media.IS_MUSIC} != 0", null,
            "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                list.add(
                    MediaItem.Builder()
                        .setMediaId(id.toString())
                        .setUri(ContentUris.withAppendedId(base, id))
                        .setMediaMetadata(
                            MediaMetadata.Builder()
                                .setTitle(c.getString(1))
                                .setArtist(c.getString(2))
                                .setArtworkUri(Uri.parse("content://media/external/audio/albumart/${c.getLong(3)}"))
                                .build()
                        ).build()
                )
            }
        }
        runOnUiThread { songs.clear(); songs.addAll(list) }
    }

    private fun checkUpdate(silent: Boolean) = thread {
        @Suppress("DEPRECATION") val cur = packageManager.getPackageInfo(packageName, 0).versionCode
        val info = try { Updater.check() } catch (e: Exception) { null }
        runOnUiThread {
            if (info != null && info.code > cur) { updMsg = "Versão atual: v$cur\nNova versão: v${info.code}"; upd = info }
            else if (!silent) Toast.makeText(this, if (info == null) "Não consegui verificar atualizações" else "Você já está na versão mais recente (v$cur)", Toast.LENGTH_LONG).show()
        }
    }

    private fun startUpdate(i: Updater.Info) {
        if (!packageManager.canRequestPackageInstalls()) {
            startActivity(Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Permita instalar apps pelo K7 e toque em Atualizar de novo", Toast.LENGTH_LONG).show()
            return
        }
        updMsg = "Baixando…"
        thread {
            try {
                val f = Updater.download(this, i.url)
                runOnUiThread { upd = null; Updater.install(this, f) }
            } catch (e: Exception) { runOnUiThread { updMsg = "Falha no download. Tente de novo." } }
        }
    }

    private fun fmt(ms: Long) = "%d:%02d".format(ms / 60000, (ms / 1000) % 60)

    @Composable
    private fun Screen() {
        LaunchedEffect(Unit) {
            while (true) {
                controller?.let { position = it.currentPosition; duration = maxOf(0L, it.duration) }
                kotlinx.coroutines.delay(250)
            }
        }
        BackHandler(showPlayer) { showPlayer = false }
        upd?.let { u ->
            AlertDialog(
                onDismissRequest = { upd = null },
                title = { Text("Atualização disponível") },
                text = { Text(updMsg) },
                confirmButton = { TextButton(onClick = { startUpdate(u) }) { Text("Baixar e instalar") } },
                dismissButton = { TextButton(onClick = { upd = null }) { Text("Depois") } }
            )
        }
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            if (showPlayer) PlayerView() else LibraryView()
            if (!showPlayer) Row(
                Modifier.fillMaxWidth().clickable { showPlayer = true }.navigationBarsPadding().padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(artist, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                TextButton(onClick = { controller?.seekToPreviousMediaItem() }) { Text("⏮") }
                TextButton(onClick = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }) { Text(if (playing) "⏸" else "▶") }
                TextButton(onClick = { controller?.seekToNextMediaItem() }) { Text("⏭") }
            }
        }
    }

    @Composable
    private fun ColumnScope.LibraryView() {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("K7", style = MaterialTheme.typography.headlineMedium, modifier = Modifier.weight(1f))
            TextButton(onClick = { checkUpdate(false) }) { Text("⟳ Atualizar") }
        }
        if (songs.isEmpty()) Text("Nenhuma música encontrada (ou sem permissão).", modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.weight(1f)) {
            itemsIndexed(songs) { i, m ->
                Column(Modifier.fillMaxWidth().clickable { play(i) }.padding(horizontal = 16.dp, vertical = 10.dp)) {
                    Text(m.mediaMetadata.title?.toString() ?: "", maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(m.mediaMetadata.artist?.toString() ?: "", style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }

    @Composable
    private fun ColumnScope.PlayerView() {
        Column(Modifier.weight(1f).fillMaxWidth().navigationBarsPadding().padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showPlayer = false }) { Text("⌄ Voltar") }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showLyrics = !showLyrics }) { Text(if (showLyrics) "Esconder letra" else "Letra") }
            }
            Text(title, style = MaterialTheme.typography.titleLarge, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(artist, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp)) { if (showLyrics) LyricsView() }
            Slider(
                value = if (duration > 0) (position.toFloat() / duration).coerceIn(0f, 1f) else 0f,
                onValueChange = { controller?.seekTo((it * duration).toLong()) }
            )
            Row(Modifier.fillMaxWidth()) {
                Text(fmt(position), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                Text(fmt(duration), style = MaterialTheme.typography.bodySmall)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                TextButton(onClick = { controller?.seekToPreviousMediaItem() }) { Text("⏮", style = MaterialTheme.typography.headlineMedium) }
                TextButton(onClick = { controller?.let { if (it.isPlaying) it.pause() else it.play() } }) { Text(if (playing) "⏸" else "▶", style = MaterialTheme.typography.headlineMedium) }
                TextButton(onClick = { controller?.seekToNextMediaItem() }) { Text("⏭", style = MaterialTheme.typography.headlineMedium) }
            }
        }
    }

    @Composable
    private fun LyricsView() {
        val r = lyrics
        if (r == null || r.lines.isEmpty()) {
            Text("Esta música não tem letra gravada no arquivo (por enquanto só MP3).")
            return
        }
        val st = rememberLazyListState()
        val idx = if (r.synced) r.lines.indexOfLast { it.ms <= position } else -1
        LaunchedEffect(idx) { if (idx >= 0) st.animateScrollToItem(maxOf(0, idx - 2)) }
        Column {
            if (!r.synced) Text("Letra sem sincronização (o arquivo não tem marcas de tempo).", style = MaterialTheme.typography.bodySmall)
            LazyColumn(state = st) {
                itemsIndexed(r.lines) { i, l ->
                    Text(
                        l.text,
                        style = if (i == idx) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyLarge,
                        color = if (i == idx) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                        modifier = Modifier.padding(vertical = 6.dp)
                    )
                }
            }
        }
    }
}
